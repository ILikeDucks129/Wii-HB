AnyTitle Deleter v1.0 by toma
Unofficial mod v7.1 by Red Squirrel
----------------------------------------
http://www.redsquirrel.tk
----------------------------------------

What's it?
This application is a mod of official AnyTitle Deleter by toma: now the real name (and not only the title ID as in the original version!) of (almost) any title will appear near it in the menu! In this way you can understand simply and immediately what you're removing! :)
All original AnyTitle Deleter functions work yet.

Little note from the author:
I know that now exists the v.1.1 by bushing that use AHBPROT but please don't flame me for this release.
My MOD v7 was coded many months ago. But then I left the WII scene for a while looking toward a new horizon: the PS3 scene. So MOD v7 was never released.
Only in the last few days I came back to play with my Wii and my thoughts returned to this program. To avoid wasting all the work done I decided to add some new function, clean up the code and finally make this release.
I decided to keep the IOS selection instead of migrating to the AHBPROT to provide an alternative to those people wishing to continue on this way (for any reason). Maybe in next versions I'll add AHBPROT support too.
I hope it will be useful to someone and please report any bug or issue. Thank you! ;D

Changelog
v7.1
-After several requests, I reintroduced the function to get titles names from database.txt for all categories.
Now the program first tries to obtain title's name from internal NAND and on failure reads it from database.txt.

How to install?
Copy the content of SD_ROOT folder in your SD root and run it using Homebrew Channel.

Credits
tona for this wonderfull application (AnyTitle Deleter).
bushing for his improvements and his "if fakesigned" function.
Waninkoko for Select IOS function.
MrClick and giantpune for their improvements to past versions.
All websites and users that kept updated their title ID databases.
My girlfriend for her patience.
